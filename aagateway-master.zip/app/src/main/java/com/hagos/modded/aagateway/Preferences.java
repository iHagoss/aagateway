package com.hagos.modded.aagateway;

public class Preferences {
    public static final String LISTENING_MODE = "listening_mode";
    public static final String IGNORE_IPV6 = "ignore_ipv6";
}
